<!DOCTYPE html>
<script src="js/jquery-3.6.3.min.js"></script>
<script src="umd.js"></script>
<script src="alex.js"></script>
<meta name="viewport" content="width=1400, initial-scale=1.0, user-scalable=yes">
<meta charset="UTF-8">
<?php
// phpcs:disable Generic.Arrays.DisallowLongArraySyntax

require_once 'ICal.php';
require_once 'Event.php';

use ICal\ICal;

try {
    $ical = new ICal('holidays.ics', array(
        'defaultSpan'                 => 2,     // Default value
        'defaultTimeZone'             => 'UTC',
        'defaultWeekStart'            => 'MO',  // Default value
        'disableCharacterReplacement' => false, // Default value
        'filterDaysAfter'             => null,  // Default value
        'filterDaysBefore'            => null,  // Default value
        'httpUserAgent'               => null,  // Default value
        'skipRecurrence'              => false, // Default value
    ));
    // $ical->initFile('ICal.ics');
    // $ical->initUrl('https://raw.githubusercontent.com/u01jmg3/ics-parser/master/examples/ICal.ics', $user = null, $password = null, $userAgent = null);
} catch (\Exception $e) {
    die($e);
}
?>

<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title>Lex's Cove</title>
  <link rel="stylesheet" href="./style.css">

</head>
<body>

<div class="wrapperx">
     <div id="slim" style="position:absolute; width:900px;font-family:rase;color:#fff;font-size:128px;line-height:256px;top:0;left:0; right:0;margin:0 auto;transform: translateX(-50%);left:50%;display:block;text-transform:uppercase;height:256px;">

    <div class="bubbax" style="float:left;">
      <div class="bubba" id="char1" style="text-align:center;float:left;"></div></div>  
      <div class="bubbax" style="float:left;">
        <div  class="bubba" id="char2" style="text-align:center;float:left;"></div></div>  
        <div class="bubbax" style="float:left;">
          <div class="bubba"  id="char3" style="text-align:center;float:left;"></div></div>  
          <div class="bubbax" style="float:left;">
            <div class="bubba"  id="char4" style="text-align:center;float:right;"></div></div>

    <div class="bubbax" style="float:left;">
      <div class="bubba" id="char5" style="text-align:center;float:left;"></div></div>  
      <div class="bubbax" style="float:left;">
        <div  class="bubba" id="char6" style="text-align:center;float:left;"></div></div>  
        <div class="bubbax" style="float:left;">
          <div class="bubba"  id="char7" style="text-align:center;float:left;"></div></div>  
          <div class="bubbax" style="float:left;">
            <div class="bubba"  id="char8" style="text-align:center;float:right;"></div></div>

    <div class="bubbax" style="float:left;">
      <div class="bubba" id="char9" style="text-align:center;float:left;"></div></div>  


   </div>
    </div>



<div id="tablz" style="top:256px;display:block;transform: translateX(-50%);left:50%;width:900px;height: 800px; position: absolute;">
<div id="chance" style="width:200px;height: 800px;font-family:literata;font-size:16px;float:left;">
<headings style="text-align:left;display:block;">Top Tags</headings>

<div class="tags">
  
  <p>
<ul>
<li><a class="color" id="chance1"></a></li>
<li><a class="color" id="chance2"></a></li>
<li><a class="color" id="chance3"></a></li>
<li><a class="color" id="chance4"></a></li>
<li><a class="color" id="chance5"></a></li>
<li><a class="color" id="chance6"></a></li>
<li><a class="color" id="chance7"></a></li>
<li><a class="color" id="chance8"></a></li>
<li><a class="color" id="chance9"></a></li>
<li><a class="color" id="chance10"></a></li>
</ul>
</p>
</div>
<br>

<headings style="text-align:left;display:block;margin-top:20px">Admin</headings>

<ul>
  
<li><a style="color:dodgerblue;text-transform:uppercase;font-family:nimbus;text-decoration:none;" href="search.php" target="_blank">Search</a></li>
 
<li><a style="color:dodgerblue;text-transform:uppercase;font-family:nimbus;text-decoration:none;" href="#">Login</a></li>


</ul>
</div>

<div id="blog" style="position: absolute;width: 500px;height: 800px;font-family:literata;font-size:16px;left: 0; right:0; margin: 0 auto;">
<headings>Who am I ?</headings>

<span style="margin-top: 32px;top: 32px;display:block;">
  
<h2>Alex Terranova</h2>
<br>
<p>
Ima computer hobbyist, and have many other hobbies... Ive taken many classes but never graduated from 
college... I feel life is too short for words... People could take it easy more often and
perhaps think about what really important... Live every day like its the last...
</p>
<br>
<br>
<br>
<a href="mailto:electrolex@yahoo.com">
<div style="font-family:nimbus;width:500px;background:#000;color:#fff;height:64px;font-size:24px;line-height:64px;text-align:center;">
CONTACT  
</div></a>
</span>
</div>


<div id="projects" style="width:200px;height: 800px;font-family:nimbus;font-size:16px;float:right;line-height:32px;">

<headings style="text-align:right;display:block;">Projects@</headings>


<ul style="text-align: right !important;">
<li style="text-align: right !important;"><span><a  class="itemsx max1" href="http://github.com/lexterror" target="_blank">Github</a></span></li>
<li style="text-align: right !important;"><span><a class="itemsx max1"  href="http://deviantart.com/electrolex" target="_blank">DeviantArt</a></span></li>
<li style="text-align: right !important;"><span><a  class="itemsx max1" href="https://blendswap.com/profile/1250833" target="_blank">BlendSwap</a></span></li>
<li style="text-align: right !important;"><span><a  class="itemsx max1" href="https://www.flickr.com/photos/193205670@N07/" target="_blank">FlickR</a></span></li>
<li style="text-align: right !important;"><span><a  class="itemsx max1" href="https://sourceforge.net/u/lexterror/profile/" target="_blank">SourceForge</a></span></li>
<li style="text-align: right !important;"><span><a  class="itemsx max1" href="https://www.facebook.com/lex.mr.rmx" target="_blank">Facebook</a></span></li>
<li style="text-align: right !important;"><span><a class="itemsx max1"  href="https://www.linkedin.com/in/alex-terranova-49320175/" target="_blank">Linkedin</a></span></li>
</ul>

<br>
<br>
<headings style="text-align:right;display:block;"><span id="moonlabel"></span></headings>




<div id="moon" style="margin-top: 50px;margin-left:104px;text-align:center;display: block; height:96px; width: 96px; font-size:24px;font-family: nimbus;line-height:96px;color:gold;padding:0px;">
</div>

</div>
</div>

<!-- partial:index.partial.html -->

  <div class="wrapper">
    <section id='steezy'>


  
   <table id="myTable" style="left:0;right:0;margin:0 auto;">
   <caption><div class='tabletitle'>On This Day</div> <div class='tablesource'>Source: Wikipedia.org</div></caption>
  </table>
   <div id="divFeed2" style=""></div>
   
    <?php
        $showExample = array(
            'interval' => true,
            'range'    => true,
            'all'      => true,
        );

    ?>

    <?php
		global $allitems;
		$allitems = array();
		$currenitem = "";
        if ($showExample['interval']) {
            $events = $ical->eventsFromInterval('2 month');

            if ($events) {
                echo '';
            }

            $count = 1;
		}
    foreach ($events as $event) {
	  $dtstart = $ical->iCalDateToDateTime($event->dtstart_array[3]);
	  $dtstart->format('d-m-Y H:i');
	  $currenitem = "<tr><td ><div class='uber'>" . $event->summary . "<br>" . $dtstart->format('d-m-Y') . "</div></td><td class='donuts'><div class='uber color'>" . $event->description . "</div></td></tr>";
	  array_push($allitems, $currenitem);
	 } 
		
    packard($allitems);
	function packard($array) {

    $myfinalstring = '';
    $myfinalstring .= "<table> <caption><div class='tabletitle'>Calendar</div> <div class='tablesource'>Source: Thunderbird.net</div></caption>";
    foreach ($array as $key)
    $myfinalstring .= $key;
    $myfinalstring .= "</table>";
    echo $myfinalstring;   
    }
    ?>

    

   



 

    



<script>


function postData()
{
var dt = new Date();
var year = dt.getFullYear();
var month = (dt.getMonth() + 1).toString().padStart(2, "0");
var day = dt.getDate().toString().padStart(2, "0");
var monthsword = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"];

// select all elements with the class name "example"



var correctfile = "otdih_haha\\" + Number(month) + "." + Number(day) + ".txt";
jQuery.get(correctfile, function(data) {
    
	
var xcx = 0;
var x = data
var x1 = x.replaceAll(",", "");
var x2 = x1.replace(/\n/g, ",");
var x2 = x2.substring(0, x2.length - 1);
var x3 = x2.replace(/['"]+/g, '');
//var x4 = x3.replace(/:$/g, "");
var x4 = x3.replaceAll(":", "");
var x5 = x4.replaceAll("  ", ":");
var keys_vals = x5.split(",");
var obj = {};
keys_vals.forEach(function(key_val) {
    var [key, val] = key_val.split(":");
    obj[key] = val;
});

var table = document.getElementById("myTable");

for (i in obj) {
   xcx++;
   //stringy += tempo;
   var row = table.insertRow(0);
   this["cell" + xcx] = row.insertCell(0);
   this["cell" + xcx].innerHTML = "<div class='uber'>Historical Events<div class='date'></div>" + i + "</div>";
   this["cell2" + xcx] = row.insertCell(1);
   this["cell2" + xcx].innerHTML =  "<div class='uber color'>" + obj[i] + "</div>";
};
 
});
}
function findProp(obj, prop, defval){
    if (typeof defval == 'undefined') defval = null;
    prop = prop.split('.');
    for (var i = 0; i < prop.length; i++) {
        if(typeof obj[prop[i]] == 'undefined')
            return defval;
        obj = obj[prop[i]];
    }
    return obj;
}
function removeDuplicates(json_all) {
var arr = [],
collection = [];

$.each(json_all, function (index, value) {
if ($.inArray(value.id, arr) == -1) {
arr.push(value.id);
collection.push(value);
}
});
return collection;
}
postData();
</script>
    

<script type="text/javascript" src="js/FeedEk.js"></script>
<script type="text/javascript">
    $(document).ready(function () {
     

			$('#divFeed2').FeedEk({
			FeedUrl: 'https://www.infowars.com/rss.xml',
    MaxCount: 15,
    DateFormat: 'dd MMMM yyyy',
    DateFormatLang: 'en',
    ShowDesc: true,
    ShowPubDate: true,
    DescCharacterLimit: 500,
           
            });

            
    });

</script>     

    </section>
</body>


</html>
<script>


function waitforit() {
var dt = new Date();
var year = dt.getFullYear();
var month = (dt.getMonth() + 1).toString().padStart(2, "0");
var day = dt.getDate().toString().padStart(2, "0");
var monthsword = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sept","Oct","Nov","Dec"];

var elements = document.getElementsByClassName("date");

// change the innerHTML of each selected element
for (var i = 0; i < elements.length; i++) {
  elements[i].innerHTML = monthsword[dt.getMonth()] + " " + day.toString();;
}



$(".uber").addClass("js-read-smore");
$(".uber").attr('data-read-smore-chars', '300');

const ReadSmore = window.readSmore

// target all read more elements
const readMoreEls = document.querySelectorAll('.js-read-smore')

const options = {
  blockClass: 'read-more',
}
// Init
ReadSmore(readMoreEls, options).init()

// class='js-read-smore' data-read-smore-chars='100'

var elementsx = $("tr td:nth-child(2)")
var countcolors=0;
var howmanyitems = Math.round(360 / elementsx.length);
// change the innerHTML of each selected element
for (var j = 0; j < elementsx.length; j++) {
  countcolors = countcolors + howmanyitems;
  elementsx[j].style.borderColor = "hsl(" + countcolors + " 50% 50%)";
}
 $(".wrapper").fadeIn(1000); 

}
function randomIntFromInterval(min, max) { // min and max included 
  return Math.floor(Math.random() * (max - min + 1) + min)
}

function formatAMPM(date) {
  
 
    var sHours = date.getHours();
    var sMinutes = date.getMinutes();
    if (sHours < 10) sHours = "0" + sHours;
    if (sMinutes < 10) sMinutes = "0" + sMinutes;
    var strTime = sHours.toString().concat(sMinutes).toString();
    return strTime;
  
 
}
//$(document).ready( waitforit() )
setTimeout(waitforit, 5000);
var mermaid=0;
function duncando() {



//var time = formatAMPM(new Date);r


var baby =  alex.replace(/\s+/g, '');
var behave = baby.split(",");
//var toot = behave.toString();
var match = []
let textx = "";
for(var i=0; i < behave.length; i++) {
    behave[i].charAt(0).toLowerCase();
}
for(var i=0; i < behave.length; i++) {
    match.push(behave[i]);
}

var gettagz = match.toString().replace(/([A-Z])/g, ' $1').trim().replaceAll(",", "");;
var finalzz = gettagz.split(" ");


var time = finalzz[Math.floor(Math.random()*finalzz.length)];




if (time.length > 9)
$("#slim").css( { marginLeft : "0px" } );
if (time.length == 9)
$("#slim").css( { marginLeft : "0px" } );
if (time.length == 8)
$("#slim").css( { marginLeft : "50px" } );
if (time.length == 7)
$("#slim").css( { marginLeft : "100px" } );
if (time.length == 6)
$("#slim").css( { marginLeft : "150px" } );
if (time.length == 5)
$("#slim").css( { marginLeft : "200px" } );
if (time.length == 4)
$("#slim").css( { marginLeft : "250px" } );
if (time.length == 3)
$("#slim").css( { marginLeft : "300px" } );
if (time.length == 2)
$("#slim").css( { marginLeft : "350px" } );
if (time.length == 1)
$("#slim").css( { marginLeft : "400px" } );









var l1 = time.charAt(0);
var l2 = time.charAt(1);
var l3 = time.charAt(2);
var l4 = time.charAt(3);
var l5 = time.charAt(4);
var l6 = time.charAt(5);
var l7 = time.charAt(6);
var l8 = time.charAt(7);
var l9 = time.charAt(8);


const rndInt1 = randomIntFromInterval(-30, 30);
const rndInt2 = randomIntFromInterval(-30, 30);
const rndInt3 = randomIntFromInterval(-30, 30);
const rndInt4 = randomIntFromInterval(-30, 30);
const rndInt5 = randomIntFromInterval(-30, 30);
const rndInt6 = randomIntFromInterval(-30, 30);
const rndInt7 = randomIntFromInterval(-30, 30);
const rndInt8 = randomIntFromInterval(-30, 30);
const rndInt9 = randomIntFromInterval(-30, 30);
const rndInt1x = randomIntFromInterval(-30, 30);
const rndInt2x = randomIntFromInterval(-30, 30);
const rndInt3x = randomIntFromInterval(-30, 30);
const rndInt4x = randomIntFromInterval(-30, 30);
const rndInt5x = randomIntFromInterval(-30, 30);
const rndInt6x = randomIntFromInterval(-30, 30);
const rndInt7x = randomIntFromInterval(-30, 30);
const rndInt8x = randomIntFromInterval(-30, 30);
const rndInt9x = randomIntFromInterval(-30, 30);
//width: calc(100% - 100px);
//var degrees = Math.floor(Math.random()*360);
//$("#aboutme").css( { "margin-left" : + rndInt + "px" } );

//$("#houra").css({'marginTop' : rndIntx + 'px'});
//$("#houra").css({'width' : '100%'});
$("#char1").css({'transform' : 'rotate('+ rndInt1 +'deg)', 'z-index' : rndInt1x });
//$("#aboutmex").css({'width' : 'calc(100% - ' + rndIntx +'px'});



$("#char1").fadeOut(0);
$("#char1").fadeIn(1000);
$("#char1").html(l1);
//$("#hourb").css({'marginTop' : rndIntx2 + 'px'});
//$("#houra").css({'width' : '100%'});
$("#char2").css({'transform' : 'rotate('+ rndInt2 +'deg)', 'z-index' : rndInt2x });
//$("#aboutmex").css({'width' : 'calc(100% - ' + rndIntx +'px'});

$("#char2").fadeOut(0);
$("#char2").fadeIn(1000);
$("#char2").html(l2);
//$("#minutea").css({'marginTop' : rndIntx3 + 'px'});
//$("#houra").css({'width' : '100%'});
$("#char3").css({'transform' : 'rotate('+ rndInt3 +'deg)', 'z-index' : rndInt3x });
//$("#aboutmex").css({'width' : 'calc(100% - ' + rndIntx +'px'});

$("#char3").fadeOut(0);
$("#char3").fadeIn(1000);
$("#char3").html(l3);
//$("#minuteb").css({'marginTop' : rndIntx4 + 'px'});
//$("#houra").css({'width' : '100%'});
$("#char4").css({'transform' : 'rotate('+ rndInt4 +'deg)', 'z-index' : rndInt4x });
//$("#aboutmex").css({'width' : 'calc(100% - ' + rndIntx +'px'});
$("#char4").fadeOut(0);
$("#char4").fadeIn(1000);
$("#char4").html(l4);
//$(".bubba").animate({marginTop: '+=800px'}, 8000);
//setTimeout(unlock, 9000);

$("#char5").css({'transform' : 'rotate('+ rndInt5 +'deg)', 'z-index' : rndInt5x });
//$("#aboutmex").css({'width' : 'calc(100% - ' + rndIntx +'px'});
$("#char5").fadeOut(0);
$("#char5").fadeIn(1000);
$("#char5").html(l5);


$("#char6").css({'transform' : 'rotate('+ rndInt6 +'deg)', 'z-index' : rndInt6x });
//$("#aboutmex").css({'width' : 'calc(100% - ' + rndIntx +'px'});
$("#char6").fadeOut(0);
$("#char6").fadeIn(1000);
$("#char6").html(l6);

$("#char7").css({'transform' : 'rotate('+ rndInt7 +'deg)', 'z-index' : rndInt7x });
//$("#aboutmex").css({'width' : 'calc(100% - ' + rndIntx +'px'});
$("#char7").fadeOut(0);
$("#char7").fadeIn(1000);
$("#char7").html(l7);

$("#char8").css({'transform' : 'rotate('+ rndInt8 +'deg)', 'z-index' : rndInt8x });
//$("#aboutmex").css({'width' : 'calc(100% - ' + rndIntx +'px'});
$("#char8").fadeOut(0);
$("#char8").fadeIn(1000);
$("#char8").html(l8);

$("#char9").css({'transform' : 'rotate('+ rndInt9 +'deg)', 'z-index' : rndInt9x });
//$("#aboutmex").css({'width' : 'calc(100% - ' + rndIntx +'px'});
$("#char9").fadeOut(0);
$("#char9").fadeIn(1000);
$("#char9").html(l9);
eatme();
}


duncando();



function eatme() {
//var date = new Date();
//var sec = date.getSeconds();
//var offset = (60 - sec) * 1000;
setTimeout(duncando, 10000);
}

//$(document).bind("click keydown keyup mousemove touchstart", duncando);
</script>

<style>
.bubbax {
width: 100px;
height:300px;
text-transform: uppercase;
position:relative;
}

.ocean { 
  height: 15%;
  width:100%;
  position:absolute;
  left:0;
  background: #015871;
 
}
.bubba {
    position:relative;
    color: #f5f5f5;
    text-shadow: 1px 1px 1px #919191,
        1px 2px 1px #919191,
        1px 3px 1px #919191,
        1px 4px 1px #919191,
        1px 5px 1px #919191,
        1px 6px 1px #919191,
        1px 7px 1px #919191,
        1px 8px 1px #919191,
        1px 9px 1px #919191,
        1px 10px 1px #919191,
    1px 18px 6px rgba(16,16,16,0.4),
    1px 22px 10px rgba(16,16,16,0.2),
    1px 25px 35px rgba(16,16,16,0.2),
    1px 30px 60px rgba(16,16,16,0.4);
}
</style>
<style>
  

  * {
  margin: 0;
  padding: 0;
  border:0;
  }
  /*
 .tags a.color1 {background: #f58220;}
.tags a.color1:after {border-color: transparent transparent transparent #f58220}
.tags a.color2 {background: #97c224;}
.tags a.color2:after {border-color: transparent transparent transparent #97c224}
.tags a.color3 {background: #de3f3e;}
.tags a.color3:after {border-color: transparent transparent transparent #de3f3e}
.tags a.color4 {background: #ec008c;}
.tags a.color4:after {border-color: transparent transparent transparent #ec008c}
.tags a.color5 {background: #00a6df;}
.tags a.color5:after {border-color: transparent transparent transparent #00a6df}	
.tags a:hover {background:#222 !important}
.tags a:hover:after {border-color:transparent transparent transparent #222!important}


.tags a.color {background: #aaa;}
.tags a.color:after {border-color: var(--color, transparent transparent transparent #aaa) }


.tags a:hover {background:#222 !important}
.tags a:hover:after {border-color:transparent transparent transparent #222!important}
*/
	
.toptags {




}
li {
text-align: left;
width:200px;
height: 24px;
margin-top:10px;
}
li span {
   
   

}
ul li {
    
	
}
h1 {
text-transform: uppercase;
font-family: nimbus;
font-size: 64px;
line-height: 64px;
float:left;
margin-top:30px;
height:64px;
display: block;
}

h3 {
text-transform: uppercase;
font-family: nimbus;
font-size: 32px;
line-height: 64px;
float:right;
margin-top:30px;
height:64px;
display: block;
font-style: italic;
}


headings {

font-family: nimbus;
font-size: 32px;
color: #000;
line-height: 32px;
width: 200px;
height: 32px;
}
ul {
text-align:left;
 list-style:none;
 margin-top: 50px;
}



hr {

}
span {

}
#projects a {
  color:dodgerblue;
  text-decoration: none;
}

#blog a {
  
  text-decoration: none;
}

#blog p {
  
  line-height: 32px;
}

h2 {
  font-family: nimbus;
  color:#333;
}
</style>  
<script>
const str2 = alex.replace(",","").replace(" ", "");
var ppp2 = [];
var cube2 = "";
var cubex2 = [];
var cubestr2 = "";
var p2x = alex.match(/[A-Z][a-z]+|[0-9]+/g).join(" ");
ppp2 = p2x.split(" ");


for (p =0; p < ppp2.length;p++)
for (m =0; m < ppp2.length;m++)
{
    if (p != m)
    if (ppp2[p] == (ppp2[m])) {
      cube2 = cube2 + ppp2[m] + ",";
    }


}
var cubz2 = cube2.split(",");



const num = 10;
const mostFrequent = (arr = [], num = 1) => {
   const map = {};
   let keys = [];
   for (let i = 0; i < arr.length; i++) {
      if (map[arr[i]]) {
         map[arr[i]]++;
      } else {
         map[arr[i]] = 1;
      }
   }
   for (let i in map) {
      keys.push(i);
   }
   keys = keys.sort((a, b) => {

      if (map[a] === map[b]) {

         if (a > b) {
            return 1;
         } else {
            return -1;
         }
      }
      else {
         return map[b] - map[a];
      }
   })
   .slice(0, num);
   return keys;
};
cubex2 = mostFrequent(cubz2,num);
cubestr2 = cubex2.toString();



document.getElementById('chance1').innerHTML = 
"#" + cubex2[0];
document.getElementById('chance2').innerHTML = 
"#" + cubex2[1];
document.getElementById('chance3').innerHTML = 
"#" + cubex2[2];
document.getElementById('chance4').innerHTML = 
"#" + cubex2[3];
document.getElementById('chance5').innerHTML = 
"#" + cubex2[4];
document.getElementById('chance6').innerHTML = 
"#" + cubex2[5];
document.getElementById('chance7').innerHTML = 
"#" + cubex2[6];
document.getElementById('chance8').innerHTML = 
"#" + cubex2[7];
document.getElementById('chance9').innerHTML = 
"#" + cubex2[8];
document.getElementById('chance10').innerHTML = 
"#" + cubex2[9];
</script>
<style>
.max1 {
  
  text-transform: uppercase;
}
 
/* Css3 tags */
	
.tags a {
	display: inline-block;
	height:24px;
	line-height:23px;
	position:relative;
	margin: 0 12px 8px 0;
	padding: 0 12px 0 10px;
	background: #777;
	-moz-border-radius-bottomleft: 5px;
	-webkit-border-bottom-left-radius: 5px;
	border-bottom-left-radius: 5px;
	-moz-border-radius-topleft: 5px;
	-webkit-border-top-left-radius: 5px;
	border-top-left-radius: 5px;
	box-shadow: 0 1px 2px rgba(0,0,0,0.2);
	color: #fff;
	font-size:12px;
	font-family: "Lucida Grande","Lucida Sans Unicode",Verdana,sans-serif;
	text-decoration: none;
	text-shadow: 0 1px 2px rgba(0,0,0,0.2);
	font-weight: bold;
	float: left;
	}
	
.tags a:before {
	content: "";
	position: absolute;
	top: 10px;
	right: 1px;
	float: left;
	width: 5px;
	height: 5px;
	-moz-border-radius: 50%;
	-webkit-border-radius: 50%;
	border-radius: 50%;
	background: #fff;
	-moz-box-shadow: -1px -1px 2px rgba(0,0,0,0.4);
	-webkit-box-shadow: -1px -1px 2px rgba(0,0,0,0.4);
	box-shadow: -1px -1px 2px rgba(0,0,0,0.4);
	}
	
.tags a:after {
	content: "";
	position: absolute;
	top:0;
	right: -12px;
	width: 0;
	height: 0;
	border-color: var(--color, transparent transparent transparent #000) ;
	border-style: solid;
	border-width: 12px 0 12px 12px;
	}
    
    p {
	margin: 0 0 20px 0;
}
  
</style>
<script>
var elementsx = $(".tags a")
var countcolors=0;
var howmanyitems = Math.round(360 / elementsx.length);
// change the innerHTML of each selected element
for (var j = 0; j < elementsx.length; j++) {
  countcolors = countcolors + howmanyitems;
  elementsx[j].style.background = "hsl(" + countcolors + " 100% 50%)";
}
var elementsx = $(".tags a")
var countcolors=0;
var howmanyitems = Math.round(360 / elementsx.length);
// change the innerHTML of each selected element
for (var j = 0; j < elementsx.length; j++) {
  countcolors = countcolors + howmanyitems;
  
  elementsx[j].style.setProperty("--color", "transparent transparent transparent " + "hsl(" + countcolors + " 100% 50%)");
}

</script>

<script src="suncalc.js"></script>
<script src="planet_phase.js"></script>
<script>
var sign = "";
var fraction = "";
var phaseconv = 0;
var booldir = false;
function moon() {
	var phase = SunCalc.getMoonIllumination(new Date()).phase;
	if (phase > 0 && phase <= 0.5)
		sign = " &uarr;";
	if (phase > 0.5)
		sign = " &darr;";
	fraction = parseInt(SunCalc.getMoonIllumination(new Date()).fraction * 100);
	if (sign == " &darr;")
	{
	  booldir = true;
	  phaseconv = phase * 2;
	}
	if (sign == " &uarr;")
	{
	  booldir = false;
	  var newphase = phase - 0.5;
	  phaseconv = newphase * 2;
	}
	
	drawPlanetPhase(document.getElementById('moon'), phaseconv, booldir);
	document.getElementById("moonlabel").innerHTML = fraction + "%" + sign;
}
moon();
</script>
<style>
hr  {
    overflow: visible; /* For IE */
    padding: 0;
    border: none;
    border-top: medium double #333;
    color: #333;
    text-align: center;
    margin-top:15px;
}
hr:after {
    content: "ॐ";
    display: inline-block;
    position: relative;
    top: -0.7em;
    font-size: 16px;
    line-height 16px;
    padding: 0 0.25em;
    background: white;
}
</style>

